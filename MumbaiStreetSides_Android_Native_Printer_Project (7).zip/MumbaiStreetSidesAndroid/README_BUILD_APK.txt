MUMBAI STREET SIDE'S — ANDROID POS APP
======================================

This is an Android Studio source project (not a pre-built APK).
It includes the latest chalkboard / transparent kitchen-themed POS HTML and a native Android printer bridge.

ANDROID NATIVE PRINTER FEATURES
- Bluetooth: asks for Nearby devices permission, shows printers already paired in Android, and connects to an SPP/RFCOMM thermal printer.
  Pair a new printer first in Android Settings > Bluetooth. Not all Bluetooth printers use SPP.
- USB / OTG: lists connected USB devices, asks for Android USB permission, and writes to a bulk OUT interface when the printer exposes one.
  Some printers require a manufacturer-specific driver/protocol.
- Wi-Fi: searches local-network mDNS printer advertisements (_printer._tcp and _pdl-datastream._tcp), and also supports a manually entered IP address and TCP port (usually 9100 for ESC/POS printers).
- Customer receipts, test prints and kitchen tickets are sent as basic ESC/POS text with a cut command.

IMPORTANT COMPATIBILITY NOTES
- Android must grant the requested Bluetooth / USB permissions.
- Bluetooth pairing is controlled by Android; the app does not bypass pairing or permission prompts.
- Wi-Fi discovery only finds printers that advertise supported mDNS services. Many low-cost printers do not; enter their IP address manually.
- Direct printing is intended for ESC/POS-compatible thermal printers. Printer command sets and character encodings vary by model. Test with your exact printer before using it for live orders.
- This native hardware bridge is Android-only. The HTML opened directly in Chrome on a laptop retains browser/system print behavior.
- Sales data remains in this device's WebView local storage. This project does not add cloud sync or payment gateway processing.

BUILD APK WITH ANDROID STUDIO
1. Install Android Studio on a laptop/PC.
2. Open the folder MumbaiStreetSidesAndroid (the folder containing settings.gradle.kts).
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK will be at app/build/outputs/apk/debug/app-debug.apk.
6. Transfer the APK to your Android phone and install it. Android may ask you to allow installation from that source.

AUTOMATED BUILD OPTION
The included .github/workflows/build-apk.yml builds a debug APK when manually run from GitHub Actions or when code is pushed to main. Upload this project to a GitHub repository, then open Actions > Build Mumbai Street Side's APK > Run workflow. Download the artifact named Mumbai-Street-Sides-debug-APK.
