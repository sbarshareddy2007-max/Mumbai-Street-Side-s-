package com.mumbaistreetsides.pos

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.PendingIntent
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.view.WindowManager
import android.widget.Toast
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.util.UUID
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val sppUuid: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private var btSocket: BluetoothSocket? = null
    private var usbConnection: UsbDeviceConnection? = null
    private var usbEndpoint: UsbEndpoint? = null
    private var usbInterface: UsbInterface? = null
    private var selectedUsb: UsbDevice? = null
    private var wifiIp = ""
    private var wifiPort = 9100
    private var activeTransport = ""
    private var nsdManager: NsdManager? = null
    private var multicastLock: android.net.wifi.WifiManager.MulticastLock? = null
    private val discoveredWifi = linkedMapOf<String, String>()
    private val discoveredWifiPorts = linkedMapOf<String, Int>()
    private val io = Executors.newCachedThreadPool()
    private val usbPermissionAction = "${BuildConfig.APPLICATION_ID}.USB_PERMISSION"

    private val usbReceiver = object : BroadcastReceiver() {
        @Suppress("DEPRECATION")
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action != usbPermissionAction) return
            val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
            val device: UsbDevice? = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
                         else intent.getParcelableExtra(UsbManager.EXTRA_DEVICE)
            if (granted && device != null) openUsb(device) else jsStatus("USB permission was not granted.")
        }
    }

    @Suppress("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        val filter = IntentFilter(usbPermissionAction)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(usbReceiver, filter, RECEIVER_NOT_EXPORTED) else registerReceiver(usbReceiver, filter)
        nsdManager = getSystemService(Context.NSD_SERVICE) as NsdManager
        webView = WebView(this)
        webView.setBackgroundColor(android.graphics.Color.rgb(35, 31, 28))
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.settings.databaseEnabled = true
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(NativePrinterBridge(), "MSSNative")
        webView.isFocusable = true
        webView.isFocusableInTouchMode = true
        setContentView(webView)
        if (savedInstanceState == null) webView.loadUrl("file:///android_asset/index.html") else webView.restoreState(savedInstanceState)
    }

    private fun jsStatus(message: String) {
        runOnUiThread {
            val safe = message.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ")
            if (::webView.isInitialized) webView.evaluateJavascript("if(window.printerMessage)printerMessage('$safe');", null)
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
        }
    }

    private fun requireBluetoothPermission(after: () -> Unit) {
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN), 71)
            pendingBluetoothAction = after
        } else after()
    }
    private var pendingBluetoothAction: (() -> Unit)? = null
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 71) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) pendingBluetoothAction?.invoke()
            else jsStatus("Bluetooth permission is required. Allow it and scan again.")
            pendingBluetoothAction = null
        }
    }

    private fun scanBluetooth() {
        requireBluetoothPermission {
            val adapter = BluetoothAdapter.getDefaultAdapter()
            if (adapter == null) { jsStatus("This Android device does not support Bluetooth."); return@requireBluetoothPermission }
            if (!adapter.isEnabled) {
                jsStatus("Please turn on Bluetooth when Android asks, then tap Scan Bluetooth again.")
                startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)); return@requireBluetoothPermission
            }
            try {
                val devices = adapter.bondedDevices.toList().sortedBy { it.name ?: it.address }
                if (devices.isEmpty()) {
                    AlertDialog.Builder(this).setTitle("No paired printer found")
                        .setMessage("Pair your thermal printer in Android Settings → Bluetooth, then return and scan again.")
                        .setPositiveButton("Open Bluetooth settings") { _, _ -> startActivity(Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS)) }
                        .setNegativeButton("Cancel", null).show()
                } else {
                    val labels = devices.map { "${it.name ?: "Bluetooth device"}\n${it.address}" }.toTypedArray()
                    AlertDialog.Builder(this).setTitle("Choose your paired printer").setItems(labels) { _, which -> connectBluetooth(devices[which]) }.setNegativeButton("Cancel", null).show()
                }
            } catch (_: SecurityException) { jsStatus("Bluetooth permission is missing. Allow Nearby devices permission.") }
        }
    }

    private fun connectBluetooth(device: BluetoothDevice) {
        jsStatus("Connecting to ${device.name ?: "Bluetooth printer"}…")
        io.execute {
            try {
                btSocket?.close()
                val socket = device.createRfcommSocketToServiceRecord(sppUuid)
                socket.connect(); btSocket = socket; activeTransport = "bluetooth"
                jsStatus("Connected to ${device.name ?: "Bluetooth printer"}. Test print is ready.")
            } catch (e: Exception) { jsStatus("Bluetooth connection failed: ${e.message ?: "check printer power and pairing"}") }
        }
    }

    private fun scanUsb() {
        val manager = getSystemService(Context.USB_SERVICE) as UsbManager
        val devices = manager.deviceList.values.toList()
        if (devices.isEmpty()) { jsStatus("No USB device found. Connect the printer with a compatible OTG adapter and try again."); return }
        val labels = devices.map { d -> "${d.productName ?: "USB device"}  (Vendor ${d.vendorId}, Product ${d.productId})" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Choose USB / OTG printer").setItems(labels) { _, which ->
            val device = devices[which]
            if (manager.hasPermission(device)) openUsb(device) else {
                val pi = PendingIntent.getBroadcast(this, 0, Intent(usbPermissionAction).setPackage(packageName), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                manager.requestPermission(device, pi); jsStatus("Approve the USB access prompt to connect the printer.")
            }
        }.setNegativeButton("Cancel", null).show()
    }

    private fun openUsb(device: UsbDevice) {
        val manager = getSystemService(Context.USB_SERVICE) as UsbManager
        try {
            for (i in 0 until device.interfaceCount) {
                val intf = device.getInterface(i)
                for (j in 0 until intf.endpointCount) {
                    val ep = intf.getEndpoint(j)
                    if (ep.direction == UsbConstants.USB_DIR_OUT && ep.type == UsbConstants.USB_ENDPOINT_XFER_BULK) {
                        val connection = manager.openDevice(device) ?: continue
                        if (connection.claimInterface(intf, true)) {
                            usbConnection?.close(); usbConnection = connection; usbEndpoint = ep; usbInterface = intf; selectedUsb = device; activeTransport = "usb"
                            jsStatus("Connected to ${device.productName ?: "USB printer"}. Test print is ready."); return
                        }
                        connection.close()
                    }
                }
            }
            jsStatus("USB device found, but no compatible bulk-print interface was detected. A printer-specific driver may be required.")
        } catch (e: Exception) { jsStatus("USB connection failed: ${e.message}") }
    }

    private fun scanWifi() {
        discoveredWifi.clear(); discoveredWifiPorts.clear()
        try { val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as android.net.wifi.WifiManager; multicastLock = wm.createMulticastLock("mss-printer-discovery").apply { setReferenceCounted(false); acquire() } } catch (_: Exception) {}
        val manager = nsdManager ?: return
        jsStatus("Searching the local Wi-Fi network for printers advertising standard print services…")
        val types = listOf("_printer._tcp.", "_pdl-datastream._tcp.")
        var remaining = types.size
        val listeners = mutableListOf<NsdManager.DiscoveryListener>()
        types.forEach { type ->
            val listener = object : NsdManager.DiscoveryListener {
                override fun onDiscoveryStarted(serviceType: String) {}
                override fun onServiceFound(service: NsdServiceInfo) {
                    manager.resolveService(service, object : NsdManager.ResolveListener {
                        override fun onResolveFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {}
                        override fun onServiceResolved(serviceInfo: NsdServiceInfo) {
                            val host = serviceInfo.host?.hostAddress ?: return
                            discoveredWifi[host] = "${serviceInfo.serviceName} · $host:${serviceInfo.port}"; discoveredWifiPorts[host] = serviceInfo.port
                        }
                    })
                }
                override fun onServiceLost(service: NsdServiceInfo) {}
                override fun onDiscoveryStopped(serviceType: String) {}
                override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) { try { manager.stopServiceDiscovery(this) } catch (_: Exception) {}; remaining--; finishWifiScanIfReady(remaining) }
                override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) { try { manager.stopServiceDiscovery(this) } catch (_: Exception) {} }
            }
            listeners.add(listener)
            try { manager.discoverServices(type, NsdManager.PROTOCOL_DNS_SD, listener) } catch (_: Exception) { remaining--; finishWifiScanIfReady(remaining) }
        }
        Thread {
            Thread.sleep(7500)
            listeners.forEach { try { manager.stopServiceDiscovery(it) } catch (_: Exception) {} }
            try { multicastLock?.release(); multicastLock = null } catch (_: Exception) {}
            val found = discoveredWifi.toMap()
            runOnUiThread {
                if (found.isEmpty()) jsStatus("No advertised Wi-Fi printer found. Enter the printer IP address and port 9100, or add it through Android Printing settings.")
                else {
                    val entries = found.entries.toList()
                    AlertDialog.Builder(this).setTitle("Wi-Fi printers found").setItems(entries.map { it.value }.toTypedArray()) { _, which ->
                        wifiIp = entries[which].key; wifiPort = discoveredWifiPorts[wifiIp] ?: 9100; activeTransport = "wifi"
                        webView.evaluateJavascript("document.getElementById('printerIp').value='${wifiIp}';document.getElementById('printerPort').value='${wifiPort}';savePrinterSettings();", null)
                        jsStatus("Selected Wi-Fi printer at $wifiIp. Tap Test print to check it.")
                    }.setPositiveButton("OK", null).show()
                }
            }
        }.start()
    }
    private fun finishWifiScanIfReady(remaining: Int) { if (remaining <= 0) jsStatus("Wi-Fi printer scan finished. If none appeared, enter its IP address manually.") }

    private fun sendToPrinter(data: ByteArray, requestedType: String, ip: String, port: Int): String {
        if (requestedType == "wifi") { wifiIp = ip.trim(); wifiPort = port.coerceIn(1, 65535); activeTransport = "wifi" }
        return try {
            when (requestedType) {
                "bluetooth" -> if (btSocket?.isConnected == true) { btSocket!!.outputStream.usePrint(data); "Printed through Bluetooth." } else "Bluetooth printer is not connected. Scan and select a paired printer first."
                "usb" -> if (usbConnection != null && usbEndpoint != null) {
                    val conn = usbConnection!!; val ep = usbEndpoint!!
                    var offset = 0
                    while (offset < data.size) { val count = conn.bulkTransfer(ep, data, offset, minOf(16384, data.size - offset), 5000); if (count <= 0) throw Exception("USB printer did not accept data"); offset += count }
                    "Printed through USB / OTG."
                } else "USB / OTG printer is not connected. Scan and approve USB access first."
                "wifi" -> if (wifiIp.isNotBlank()) {
                    Socket().use { socket -> socket.connect(InetSocketAddress(wifiIp, wifiPort), 4000); socket.soTimeout = 5000; socket.getOutputStream().usePrint(data) }
                    "Printed through Wi-Fi."
                } else "Enter a Wi-Fi printer IP address and port (usually 9100)."
                else -> "No native printer connected. Connect Bluetooth, USB/OTG, or Wi-Fi printer first."
            }
        } catch (e: Exception) { "Print failed: ${e.message ?: "check printer connection"}" }
    }
    private fun OutputStream.usePrint(data: ByteArray) { write(byteArrayOf(0x1B, 0x40)); write(data); write(byteArrayOf(0x0A, 0x0A, 0x0A)); write(byteArrayOf(0x1D, 0x56, 0x00)); flush() }

    inner class NativePrinterBridge {
        @JavascriptInterface fun scanBluetooth() { runOnUiThread { this@MainActivity.scanBluetooth() } }
        @JavascriptInterface fun scanUsb() { runOnUiThread { this@MainActivity.scanUsb() } }
        @JavascriptInterface fun scanWifi() { runOnUiThread { this@MainActivity.scanWifi() } }
        @JavascriptInterface fun setWifi(ip: String, port: Int): String {
            wifiIp = ip.trim(); wifiPort = port.coerceIn(1, 65535); activeTransport = "wifi"
            return if (wifiIp.isNotBlank()) "Wi-Fi printer set to $wifiIp:$wifiPort. Tap Test print." else "Enter the Wi-Fi printer IP address."
        }
        @JavascriptInterface fun printText(value: String, type: String, ip: String, port: Int): String {
            val message = sendToPrinter(value.toByteArray(Charsets.UTF_8), type, ip, port)
            jsStatus(message); return message
        }
        @JavascriptInterface fun isAvailable(): Boolean = true
    }

    override fun onSaveInstanceState(outState: Bundle) { webView.saveState(outState); super.onSaveInstanceState(outState) }
    @Deprecated("Deprecated in Java") override fun onBackPressed() { if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed() }
    override fun onDestroy() {
        try { unregisterReceiver(usbReceiver) } catch (_: Exception) {}
        try { btSocket?.close(); usbConnection?.close(); multicastLock?.release() } catch (_: Exception) {}
        if (::webView.isInitialized) webView.destroy()
        io.shutdownNow(); super.onDestroy()
    }
}
